package com.aic.aicdelivery;

/**
 * Created by Administrator on 10-06-2017.
 */
public class HMMessageList {
     public  String  membercode="";

     public  String  transactiondate="";

     public  String  transactiontype="";

     public  String  narration="";

     public  String  narration120="";

     public  String  mmonth="";

     public  String  mday="";

     public  String  isread="";

     public  String  sequence="";
}
