package com.aic.aicdelivery;

/**
 * Created by Administrator on 05-07-2017.
 */

public class HMException extends Exception {

    public HMException(String message) {
        super(message);
    }
}
