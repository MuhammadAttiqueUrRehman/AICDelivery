package com.aic.aicdelivery;

/**
 * Created by Administrator on 10-06-2017.
 */
public class HMRecurItem {

    public String membercode = "";

    public String itemcode = "";

    public String recorderday = "";

    public String recordertime = "";

    public String orderqty = "";
}
