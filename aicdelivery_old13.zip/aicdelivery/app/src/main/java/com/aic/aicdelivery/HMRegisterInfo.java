package com.aic.aicdelivery;

/**
 * Created by Administrator on 10-06-2017.
 */
public class HMRegisterInfo {
    public  String  regFirstName="";
    public  String  regLastName="";
    public  String  regMobile="";
    public  String  regEmail="";
    public  String  regPin="";
    public  String  reValidation="";
}
