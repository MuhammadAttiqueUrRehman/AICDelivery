package com.aic.aicdelivery;

/**
 * Created by Administrator on 10-06-2017.
 */
public class HMProductList {
    public String outletcode = "";

    public String outletname = "";

    public String itemcode = "";

    public String itemname = "";

    public String itemdescription = "";

    public String manufacturercode = "";

    public String manufacturername = "";

    public String categorycode = "";

    public String categoryname = "";

    public String subcategorycode = "";

    public String subcategoryname = "";

    public String sizedetail = "";

    public String colordetail = "";

    public String measurementtyp = "";

    public String measurementunit = "";

    public String unitprice = "";

    public String availableqty = "";

    public String rewardpercent = "";

    public String barcode = "";

    public String imagesmallurl = "";

    public String imagelargeurl = "";

    public String isfav="";

    public String recurring = "";

    public String isoffer = "";

    public String offerprice = "";

    public String offerdescription = "";

    public String itemtype="";
}
