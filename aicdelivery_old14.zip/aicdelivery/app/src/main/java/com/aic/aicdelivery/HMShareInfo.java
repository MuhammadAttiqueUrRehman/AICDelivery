package com.aic.aicdelivery;

/**
 * Created by Administrator on 10-06-2017.
 */
public class HMShareInfo {
    public String name="";

    public String subject="";

    public String shortcontent="";

    public String longcontent="";

    public String imageurl="";

    public String telephone="";

    public String emailid="";
}
