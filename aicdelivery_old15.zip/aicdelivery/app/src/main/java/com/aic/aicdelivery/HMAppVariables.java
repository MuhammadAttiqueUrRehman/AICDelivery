package com.aic.aicdelivery;

/**
 * Created by Administrator on 09-06-2017.
 */
public class HMAppVariables {

    public  String appcustomeremailbody="";
    public  String appcustomeremailid="";
    public  String appcustomeremailsubject="";
    public  String appcustomertelephone="";
    public  String appdeviceexist="";
    public  double appenrolmetnamount=0;
    public  String appgoogleapikey="";
    public  double applat=0;
    public  String applocationshort="";
    public  String applocationlong="";
    public  double applon=0;
    public  String appmerchantid="";
    public  String appsocialmessagelong="";
    public  String appsocialmessageshort="";
    public  String appurl="";
    public  String ualcohol="";
    public  String uareaname="";
    public  String uautolocation="";
    public  String ubirthdate="";
    public  String ucertificate="";
    public  String ucity="";
    public  String ucityname="";
    public  String ucountry="";
    public  String ucountryname="";
    public  String ucurrency="";
    public  String ucuspic="";
    public  String ucusqr="";
    public  String ucustomerid="";
    public  String ucustomername="";
    public  String udisplaybirthdate="";
    public  String uemailid="";
    public  String ufbid="";
    public  String ufirstname="";
    public  String ufullname="";
    public  String uhomecountry="";
    public  String uhomecountryname="";
    public  String uinitdate="";
    public  String ulastname="";
    public  String ulocationname="";
    public  boolean ulogged=false;
    public  String umagicnumber="";
    public  double umaxspend=0;
    public  String umemberexpiry="";
    public  String umobilenumber="";
    public  String unationalitycode="";
    public  String upinnumber="";
    public  double upointvalue=0;
    public  String upushoffer="";
    public  String uremindexpiry="";
    public  String uresidentcity="";
    public  String uresidentcountry="";
    public  String uresidentcountryname="";
    public  String usegmentcode="";
    public  String usegmentimage="";
    public  String usegmentname="";
    public  String ushowprofile="";
    public  double uspend=0;
    public String  udevicecomboined="";
    public String  firsttimeaccess="";
    public String  sendNotification="";
    public String  sendMailer="";
    public String  sendSMS="";
}
