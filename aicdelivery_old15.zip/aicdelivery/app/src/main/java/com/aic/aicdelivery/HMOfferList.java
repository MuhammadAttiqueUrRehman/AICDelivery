package com.aic.aicdelivery;

/**
 * Created by Administrator on 10-06-2017.
 */
public class HMOfferList {

    public String outletcode = "";

    public String itemcode = "";

    public String itemname = "";

    public String itemdescription = "";

    public String category = "";

    public String couponexpirydate = "";

    public String remark = "";

    public String imageurls = "";

    public String imageurll = "";

    public String smessage = "";

    public String menuCat = "";

    public String couponcode = "";

    public String itemqty = "";

    public String price = "";

    public String isfav = "";

    public String recurring = "";
}
