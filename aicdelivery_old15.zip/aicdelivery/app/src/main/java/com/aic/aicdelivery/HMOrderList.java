package com.aic.aicdelivery;

/**
 * Created by Administrator on 10-06-2017.
 */
public class HMOrderList {

    public String membercode = "";

    public String orderid = "";

    public String transactiondate = "";

    public String outlet = "";

    public String outletname = "";

    public String deliverydate = "";

    public String paymentamount = "";

    public String rewards = "";

    public String deliverystatus = "";

    public String paymenttype = "";

    public String itemcount = "";

    public String mmonth = "";

    public String mday = "";
}
