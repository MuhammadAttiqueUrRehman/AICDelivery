package com.aic.aicdelivery;

/**
 * Created by Administrator on 11-06-2017.
 */
public class HMWriteCoreData {
    HMCoreData coreData;
    HMAppVariables appVariables;



}
