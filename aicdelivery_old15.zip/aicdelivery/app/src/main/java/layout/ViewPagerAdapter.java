package layout;

interface ViewPagerAdapter {
}
