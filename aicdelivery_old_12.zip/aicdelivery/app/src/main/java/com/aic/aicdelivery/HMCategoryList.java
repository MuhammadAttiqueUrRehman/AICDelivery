package com.aic.aicdelivery;

/**
 * Created by Administrator on 10-06-2017.
 */
public class HMCategoryList {
    public String  categorycode="";

    public String  subcategorycode="";

    public String  subcategoryname="";

    public String  subcategorydesc="";

    public double  vatpercentage=0;

    public String  mastercode="";

    public String  imagelargeurl="";

    public String  menuCat="";
}
