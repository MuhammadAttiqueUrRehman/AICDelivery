package com.aic.aicdelivery;

/**
 * Created by Administrator on 10-06-2017.
 */
public class HMOutletList {
    public String outletcode = "";

    public String outletname = "";

    public String outletshort = "";

    public String outletlong = "";

    public String brandcode = "";

    public String geolocation = "";

    public String hotelname = "";

    public String reviewcount = "";

    public String staraverage = "";

    public String imageurls = "";

    public String imageurll = "";

    public String telephone = "";

    public String emailid = "";

    public String lat = "";

    public String lon = "";

    public String beaconuid = "";

    public String beaconname = "";

    public String beaconmajor = "";

    public String beaconminor = "";

    public String messagenotification = "";

    public String radius = "";

    public String outletfavourite = "";

    public String outletdistance = "";

    public String communitydistance = "";

    public String menuCat = "";
}
