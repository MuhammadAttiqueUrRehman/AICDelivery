package com.aic.aicdelivery;

import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.ArrayList;

public class questionAdapter  extends RecyclerView.Adapter<questionAdapter.CustomViewHolder>  {
    private Context context;
    private ArrayList<detailitemVO> items;
    private int cuslayout;
    private int lastSelectedPosition = -1;
    private int formoption;
    private String qadata;
    private HMCoreData hmcoredata;
    private IntroManager intromanager;
  private String firsttime ="";
    public questionAdapter(FragmentActivity activity, ArrayList<detailitemVO> items, int cuslayout,int formoption,String qadata) {
        this.context = activity;
        this.items = items;
        this.cuslayout=cuslayout;
        this.formoption=formoption;
        this.qadata=qadata;
        hmcoredata=new HMCoreData(this.context);
        intromanager=new IntroManager(this.context);
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new CustomViewHolder(LayoutInflater.from(context).inflate(cuslayout, parent, false));
    }

    @Override
    public void onBindViewHolder(questionAdapter.CustomViewHolder holder, int position) {
        final detailitemVO album = items.get(position);
        holder.detailQ.setText(album.getDetailq());
        holder.detailR.setText(album.getDetailr());
    //    hmcoredata.showToast(context,Integer.toString(position));
        if (album.getDetailr().equals(qadata) && firsttime.equals("")){
            holder.detailQ.setChecked(true);
            firsttime="1";
        } else{
            holder.detailQ.setChecked(lastSelectedPosition == position);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {

        private RadioButton detailQ;
        private TextView detailR;

        public CustomViewHolder(View view) {
            super(view);
            detailQ = view.findViewById(R.id.questcode);
            detailR = view.findViewById(R.id.optionvalue);

            detailQ.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    notifyItemRangeChanged(0,  items.size());
                    lastSelectedPosition = getAdapterPosition();
                    //hmcoredata.alertBox(context,detailR.getText().toString());
                    if (formoption == 1) {
                        intromanager.setQAOption1(detailR.getText().toString());
                    } else if (formoption == 2) {
                        intromanager.setQAOption2(detailR.getText().toString());
                    } else if (formoption == 3) {
                        intromanager.setQAOption3(detailR.getText().toString());
                    } else if (formoption == 4) {
                        intromanager.setQAOption4(detailR.getText().toString());
                    } else if (formoption == 5) {
                        intromanager.setQAOption5(detailR.getText().toString());
                    }
                    notifyDataSetChanged();
                }
            });
        }
    }

}
